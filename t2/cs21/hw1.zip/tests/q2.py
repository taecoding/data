test = {   'name': 'q2',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> f = fiberator();\n>>> assert next(f) == 0;\n>>> assert next(f) == 1\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
