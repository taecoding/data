test = {   'name': 'q1',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> user_input = [100, 2];\n>>> user_output = "102";\n>>> run_assignment(hw2_a1, user_input)\n\'102\'', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
